package cs451;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ConfigParser {

    private String path;
    private int nMsgs;
    private int processIndex ;

    public boolean populate(String value) {
        File file = new File(value);
        path = file.getPath();
        try {
            nMsgs = Integer.valueOf(Files.readAllLines(file.toPath()).get(0).split(" ")[0]);
            processIndex = Integer.valueOf(Files.readAllLines(file.toPath()).get(0).split(" ")[1]);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    public String getPath() {
        return path;
    }

    public int getnMsgs() {
        return nMsgs ;
    }

    public int getProcessIndex() {
        return processIndex;
    }
}
