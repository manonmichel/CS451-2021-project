package cs451.Messages;

import java.io.*;

public class Message implements Serializable {

    private final int SeqNumber;
    private final String content;
    private String srcIP, dstIP;
    private int srcPort, dstPort;
    private final MessageType msgType ;


    public Message(int SeqNumber, String content, MessageType msgType){
        this.content = content ;
        this.SeqNumber = SeqNumber ;
        this.msgType = msgType;
    }

    public Message(int SeqNumber, String content, MessageType msgType, String srcIP, int srcPort, String dstIP, int dstPort){
        this.content = content ;
        this.SeqNumber = SeqNumber ;
        this.msgType = msgType;
        this.srcIP = srcIP;
        this.dstIP = dstIP ;
        this.srcPort = srcPort ;
        this.dstPort = dstPort ;
    }


    public int getSeqNumber() { return SeqNumber;}

    public String getContent() {
        return content;
    }

    public MessageType getMsgType() { return msgType; }

    public String getSrcIP(){ return this.srcIP; }

    public String getDstIP(){ return this.dstIP; }

    public int getSrcPort(){ return this.srcPort; }

    public int getDstPort(){ return this.dstPort; }

    public boolean compare(Message m1, Message m2){
        return m2.SeqNumber == m1.SeqNumber && m1.content == m2.content && m1.msgType == m2.msgType ;
    }

    public byte[] msgToBytes() throws IOException {
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        ObjectOutputStream objectStream = null;
        byte[] msgAsBytes = null ;
        try {
            objectStream = new ObjectOutputStream(byteStream);
            objectStream.writeObject(this);
            objectStream.flush();
            msgAsBytes = byteStream.toByteArray();
        } finally {
            try {
                byteStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(msgAsBytes == null){
            throw new InvalidObjectException("Resulting byte array is null") ;
        }

        return msgAsBytes;
    }

    public static Message msgFromBytes(byte[] msgAsBytes){
        ByteArrayInputStream byteStream = new ByteArrayInputStream(msgAsBytes);
        ObjectInput obj = null;
        Message msg = null;
        try {
            obj = new ObjectInputStream(byteStream);
            msg = (Message) obj.readObject();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (obj != null) {
                    obj.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if(msg == null){
            throw new NullPointerException("Resulting Message is null") ;
        }

        return msg ;
    }

    public Message genAck(){
        return new Message(this.getSeqNumber(), "", MessageType.ACK, this.dstIP, this.dstPort, this.srcIP, this.srcPort);
    }

}