package cs451.ProcessHandlers;

import cs451.Host;
import cs451.Messages.Message;
import cs451.Messages.MessageType;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashMap;

public class FairlossLink {

    private static final int MAX_BYTES = 65535;

    private DatagramSocket socket;

    private final int port ;
    private final String ip ;
    private final int id;

    private final HashMap<Message, byte[]> cache = new HashMap(); // cache to avoid reserializing messages

    public FairlossLink(Host currentHost) {

        this.id = currentHost.getId();
        this.ip = currentHost.getIp();
        this.port = currentHost.getPort();

        try{
            this.socket = new DatagramSocket(this.port, InetAddress.getByName(this.ip)) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Message receive() {
        byte[] msg = new byte[MAX_BYTES];
        DatagramPacket udpPacket = new DatagramPacket(msg, msg.length);
        try {
            socket.receive(udpPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Message.msgFromBytes(udpPacket.getData());
    }

    public void send(Message msg){
        try{
            byte[] msgAsBytes = cache.computeIfAbsent(msg, m -> {   // Need this because msgToBytes() throws an exception
                try {
                    return m.msgToBytes();
                }catch(IOException e) {
                    e.printStackTrace();
                    return null;
                }
            });
            if(msgAsBytes == null){
                throw new NullPointerException("Null byte array");
            }
            DatagramPacket udpPacket = new DatagramPacket(msgAsBytes, msgAsBytes.length, InetAddress.getByName(msg.getDstIP()), msg.getDstPort());
            socket.send(udpPacket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}