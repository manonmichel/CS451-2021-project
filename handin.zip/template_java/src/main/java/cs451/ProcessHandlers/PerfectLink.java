package cs451.ProcessHandlers;

import cs451.Messages.Message;

import java.util.HashMap;
import java.util.HashSet;

public class PerfectLink {

    private final int SeqNumber;
    private final String content;
    private final FairlossLink fll;

    // Keeps track of sent messages and whether they were acked or not
    private final HashMap<Integer, Boolean> sent = new HashMap();
    // Keeps track of received messages
    private final HashSet<Integer> received = new HashSet<>();

    public PerfectLink(int seqNumber, String content, FairlossLink fll){

        SeqNumber = seqNumber;
        this.content = content;
        this.fll = fll;
    }


    public void receive() {
        while (true) {
            Message msg = fll.receive();
            switch (msg.getMsgType()) {
                case BROADCAST:
                    if (!received.contains(msg.getSeqNumber())) {
                        received.add(msg.getSeqNumber());
                        System.out.println("d " + msg.getSrcPort() + " " + msg.getSeqNumber());
                    }
                    fll.send(msg.genAck());
                    break;

                case ACK:
                    if (!sent.get(msg.getSeqNumber())) {
                        sent.replace(msg.getSeqNumber(), true);
                        sender.notifyAck(m);
                    }
                    break;
                    sent.
            }
        }
    }

    public void send(Message m) {
        fll.send(m);

    }
}