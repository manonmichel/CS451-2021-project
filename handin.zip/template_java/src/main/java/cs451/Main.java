package cs451;

import cs451.Messages.Message;
import cs451.Messages.MessageType;
import cs451.ProcessHandlers.FairlossLink;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Main {

    private static void handleSignal() {
        //immediately stop network packet processing
        System.out.println("Immediately stopping network packet processing.");

        //write/flush output file if necessary
        System.out.println("Writing output.");
    }

    private static void initSignalHandlers() {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                handleSignal();
            }
        });
    }

    public static void main(String[] args) throws InterruptedException {
        Parser parser = new Parser(args);
        parser.parse();

        int nMsgs = parser.configContent()[0];
        int dstID = parser.configContent()[1];
        Host dstHost = parser.getHostFromID(dstID);
        int mask = String.valueOf(nMsgs).length();

        initSignalHandlers();

        // example
        long pid = ProcessHandle.current().pid();
        System.out.println("My PID: " + pid + "\n");
        System.out.println("From a new terminal type `kill -SIGINT " + pid + "` or `kill -SIGTERM " + pid + "` to stop processing packets\n");

        System.out.println("My ID: " + parser.myId() + "\n");
        System.out.println("List of resolved hosts is:");
        System.out.println("==========================");
        for (Host host: parser.hosts()) {
            System.out.println(host.getId());
            System.out.println("Human-readable IP: " + host.getIp());
            System.out.println("Human-readable Port: " + host.getPort());
            System.out.println();
        }
        System.out.println();

        System.out.println("Path to output:");
        System.out.println("===============");
        System.out.println(parser.output() + "\n");

        System.out.println("Path to config:");
        System.out.println("===============");
        System.out.println(parser.config() + "\n");

        System.out.println("Config content:");
        System.out.println("===============");
        System.out.println("Number of messages each process should send: " + nMsgs);
        System.out.println("Index of the process that should receive the messages: " + dstID + "\n");

        System.out.println("Doing some initialization\n");

        System.out.println("Broadcasting and delivering messages...\n");

        Host currentHost = parser.getCurrentHost();

        FairlossLink fll = new FairlossLink(currentHost);

        if(currentHost.getId() != dstID){
            for(int i = 0; i<nMsgs ; i++){
                int seqn = (int) (currentHost.getId()*Math.pow(10,mask) + i);
                Message m = new Message(seqn, Integer.toString(i), MessageType.BROADCAST, currentHost.getIp(), currentHost.getPort(), dstHost.getIp(), dstHost.getPort());
                System.out.println("sending " + i);
                fll.send(m);
            }
        } else {
            // timeouts,
            List<Host> sendingHosts = new ArrayList<>(parser.hosts()) ;
            sendingHosts.remove(currentHost);
            HashMap<Integer, List<Integer>> expecting = new HashMap<>();
            for(Host sendingHost : sendingHosts){
                expecting.put(sendingHost.getPort(), IntStream.range(0, nMsgs).boxed().collect(Collectors.toList()));
            }
            while(expecting.size() !=0) {
                Message msgReceived = fll.receive();
                expecting.get(msgReceived.getSrcPort()).remove((Integer) msgReceived.getSeqNumber());
                if(expecting.get(msgReceived.getSrcPort()).isEmpty()){
                    expecting.remove(msgReceived.getSrcPort());
                }

                Message ack = new Message(msgReceived.getSeqNumber(), "", MessageType.ACK, currentHost.getIp(), currentHost.getPort(), msgReceived.getSrcIP(), msgReceived.getSrcPort());
                fll.send(ack);
                System.out.println("received " + msgReceived.getSeqNumber() + " from " + msgReceived.getSrcPort() + "   | expecting: " + expecting.size());

            }
        }

        System.out.println("Signaling end of broadcasting messages");


        // After a process finishes broadcasting,
        // it waits forever for the delivery of messages.
        while (true) {
            // Sleep for 1 hour


            Thread.sleep(60 * 60 * 1000);
        }
    }
}
